#pragma once
#include "JAR-Template/drive.h"

class Drive;

extern Drive chassis;

void default_constants();

void worlds_Auton();
void old_AWP();
void testing();
void safe_worlds_auton();