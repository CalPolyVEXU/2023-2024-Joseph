#pragma once
#include "JAR-Template/drive.h"

class Drive;

extern Drive chassis;

void default_constants();

void six_ball_auton();
void Match_Load_AWP();
void AWP_Plus_One();
void Prog_Skills();
void odom_test();
void safe_worlds_auton();
void worlds_auton();